#include"header.h"


void surbrillance(t_personnage* Perso, BITMAP* buffer, int terrain[30][44])
{
    int taille_carre=22;
    int position_ligne_act=Perso->affichage->position_pixel_ligne/taille_carre;
    int position_ligne_col=Perso->affichage->position_pixel_colonne/taille_carre;

    for (int a=0; a<30; a++)
    {
        for (int b=0; b<44; b++)
        {
            if ((abs(position_ligne_act-a)+abs(position_ligne_col-b)<=Perso->Pm)&&(terrain[a][b]!=makecol(0,0,255))&&(terrain[a][b]!=makecol(0,100,255)))
            {
                rectfill(buffer,  (taille_carre*b)+1,   (taille_carre*a)+1,  ((taille_carre)*(b+1))-3,  ((taille_carre)*(a+1))-3,makecol(255,255,255));
            }
        }
    }

}

void placement(BITMAP* echequier,int taille_carre,int terrain[30][44],t_personnage* Perso[4], int type,BITMAP* buffer,BITMAP* Mapp,int* f ,int*confirm)
{
    blit(Mapp,buffer,0,0,0,0,1080,670);
    if (Perso[type]->sort_actif_degatif==10)
    {
        allegro_message(" Vous subissez un sort de paralysie pendant ce tour \n Vous ne pouvez donc pas bouger :(");
        *(f)=0;
    }
    else
    {
        surbrillance(Perso[type],buffer,terrain);

        if ((mouse_b&1))
        {
            while(mouse_b&1);

            int colonne=mouse_x;
            int ligne=mouse_y; // on recupere la valeur de la souris ou on a cliquer
            int X=abs((Perso[type]->affichage->position_pixel_colonne/taille_carre)-(colonne/taille_carre));
            int Y=abs((Perso[type]->affichage->position_pixel_ligne/taille_carre)-(ligne/taille_carre));

            printf(" Avant mouvement PM : %d  X : %d  Y: %d \t",Perso[type]->Pm,X,Y);

            if(Perso[type]->Pm-(X+Y)>=0)
            {
                if ((terrain[ligne/taille_carre][colonne/taille_carre]!=makecol(0,0,255))&&(terrain[ligne/taille_carre][colonne/taille_carre]!=makecol(0,100,255)))
                {
                    if ( Perso[type]->affichage->ancienne_couleur!=-1)
                    {
                        terrain[Perso[type]->affichage->position_pixel_ligne/taille_carre][Perso[type]->affichage->position_pixel_colonne/taille_carre]=Perso[type]->affichage->ancienne_couleur;
                    }
                    Perso[type]->affichage->ancienne_couleur=terrain[ligne/taille_carre][colonne/taille_carre];
                    terrain[ligne/taille_carre][colonne/taille_carre]=makecol(0,100,255);
                    Perso[type]->affichage->position_pixel_ligne=ligne;
                    Perso[type]->affichage->position_pixel_colonne=colonne;
                    Perso[type]->affichage->ligne_tab=ligne/taille_carre;
                    Perso[type]->affichage->colonne_tab=colonne/taille_carre;

                    Perso[type]->Pm=Perso[type]->Pm-(X+Y);

                    printf(" Apres mouvement PM : %d  X : %d  Y: %d \n",Perso[type]->Pm,X,Y);
                    *(f)=0;
                    *(confirm)=1;
                }
                else
                {
                    allegro_message("Placement impossible");
                    *(f)=0;
                }
                for ( int i=0; i<30; i++)
                {
                    for (int j=0; j<44; j++)
                    {
                        rectfill(echequier,  taille_carre*j,   taille_carre*i,  taille_carre*(j+1), taille_carre*(i+1),terrain[i][j]);
                    }
                }
            }
            else
            {

                allegro_message("Nombre de PM insufissant ");
                *(f)=0;
            }

        }
    }

}

void Placer_un_personnage(BITMAP* buffer, t_personnage* Perso[4], int i, int genre,int type,int type2)  // indice est l'indice d'animation, attaque ou surplace // genre==0 pour place , 1 pour attaquerr
{
    textprintf_centre_ex(buffer, font,1025,60, makecol(255,255,255),-1, "%s",Perso[type2]->nom);

    textprintf_ex(buffer, font,995,230, makecol(0,0,0),-1, "%s",Perso[type2]->Sort[0].nom_sort);
    textprintf_ex(buffer, font,995,305,makecol(0,0,0),-1, "%s",Perso[type2]->Sort[1].nom_sort);
    textprintf_ex(buffer, font,995,370, makecol(0,0,0),-1, "%s",Perso[type2]->Sort[2].nom_sort);
    textprintf_ex(buffer, font,995,435,  makecol(0,0,0),-1, "%s",Perso[type2]->Sort[3].nom_sort);

    textprintf_ex(buffer, font,1000,100, makecol(0,255,0),-1, "PV : %d",Perso[type2]->Pv);
    textprintf_ex(buffer, font,1000,120, makecol(38,196,236),-1, "PM : %d",Perso[type2]->Pm);
    textprintf_ex(buffer, font,1000,140, makecol(255,0,0),-1, "PA : %d",Perso[type2]->Pa);

    int direction=Perso[type]->affichage->direction;
    if(type==3)
    {
        direction =(Perso[type]->affichage->direction+1)%2;
    }

    if (Perso[type]->Pv>0)
    {
        int position_colonne = Perso[type]->affichage->position_pixel_colonne;
        int position_ligne = Perso[type]->affichage->position_pixel_ligne;
        if(genre==0)
        {
            int indice=Perso[type]->affichage->indice_animation_surplace;
            int taille_x=Perso[type]->affichage->surplace_taillex;
            int taille_y=Perso[type]->affichage->surplace_tailley;

            position_colonne= position_colonne-taille_x/2;
            position_ligne=position_ligne-taille_y;

            if(direction==0)
            {
                draw_sprite(buffer,Perso[type]->affichage->surplace[i%indice],position_colonne,position_ligne);
            }
            else
            {
                draw_sprite_h_flip(buffer,Perso[type]->affichage->surplace[i%indice],position_colonne,position_ligne);
            }
        }
        else
        {
            int taille_x=Perso[type]->affichage->attaque_taillex;
            int taille_y=Perso[type]->affichage->attaque_tailley;
            int indice=Perso[type]->affichage->indice_animation_attaque;

            position_colonne= position_colonne-taille_x/2;
            position_ligne=position_ligne-taille_y;
            if(direction==0)
            {
                draw_sprite(buffer,Perso[type]->affichage->attaque[i%indice],position_colonne-Perso[type]->affichage->difference_deposX,position_ligne-Perso[type]->affichage->difference_deposY);
            }
            else
            {
                draw_sprite_h_flip(buffer,Perso[type]->affichage->attaque[i%indice],(position_colonne+Perso[type]->affichage->difference_deposX),(position_ligne-Perso[type]->affichage->difference_deposY));
            }
        }
    }
}
