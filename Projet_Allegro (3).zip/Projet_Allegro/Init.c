#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include<allegro.h>
#include <time.h>
#include"header.h"


BITMAP* recup_sprites( BITMAP*scr,int w,int h,int startx,int starty,int col,int element)
{
    BITMAP *bmp;
    int x,y;
    bmp=create_bitmap(w,h);
    if (bmp!=NULL)
    {
        x = startx + (element%col)*w;
        y = starty + (element/col)*h;
        blit( scr, bmp, x, y, 0, 0, w, h);

    }
    return bmp;
}

BITMAP *chargerImage(char *nomFichierImage)
{
    BITMAP *bmp;
    bmp=load_bitmap(nomFichierImage,NULL);
    if (bmp==NULL)
    {
        allegro_message("Erreur de chargement %s",nomFichierImage);
        allegro_exit();
        exit(EXIT_FAILURE);
    }
    return bmp;
}


void initalisation_personnages(t_personnage* Perso[4],int terrain[30][44],BITMAP*echequier,BITMAP*collision)
{
    int taille_carre=660/30;

    for (int a=0; a<30; a++)
    {
        for (int b=0; b<44; b++)
        {
            int c=0;
            c=(int)getpixel(collision,taille_carre*b+11, taille_carre*a+ 11) ;
            if (c==makecol(127,127,127))
            {
               rectfill(echequier,  taille_carre*b,   taille_carre*a,  taille_carre*(b+1), taille_carre*(a+1),makecol(0,0,255));
            }
            else if (c!=0)
            {
                rectfill(echequier,  taille_carre*b,   taille_carre*a,  taille_carre*(b+1), taille_carre*(a+1),c);
            }
            else
            {
                if ((b%2==0))
                {
                    if (a%2==0)
                    {
                        rectfill(echequier,  taille_carre*b,   taille_carre*a,  taille_carre*(b+1), taille_carre*(a+1), makecol(255,255,255));
                    }
                    else
                    {
                        rectfill(echequier,  taille_carre*b,   taille_carre*a,  taille_carre*(b+1), taille_carre*(a+1), makecol(0,0,0));
                    }
                }
                else
                {
                    if (a%2==0)
                    {
                        rectfill(echequier,  taille_carre*b,   taille_carre*a,  taille_carre*(b+1), taille_carre*(a+1), makecol(0,0,0));
                    }
                    else
                    {
                        rectfill(echequier,  taille_carre*b,   taille_carre*a,  taille_carre*(b+1), taille_carre*(a+1), makecol(255,255,255));
                    }
                }
            }
            c=(int)getpixel(echequier,taille_carre*b+11, taille_carre*a+ 11) ;
            terrain[a][b]=c;
        }
    }

    for (int i=0;i<4;i++)
    {

        Perso[i]=(t_personnage*)malloc(sizeof(t_personnage));
        Perso[i]->affichage=(t_affichage*)malloc(sizeof(t_affichage));
        Perso[i]->Pa=10;
        Perso[i]->Pm=10;
        Perso[i]->sort_actif_degatif=0;
        Perso[i]->sort_actif_positif=0;
        Perso[i]->compteur_sort_boost=0;
        Perso[i]->compteur_sort_entrave=0;

        Perso[i]->parametre_avant_sort=0;

        Perso[i]->fin_sort_boost=0;
        Perso[i]->fin_sort_entrave=0;

        Perso[i]->Pm=20;

        Perso[i]->Pv=50;
        Perso[i]->portee_attaque=3;
        Perso[i]->classe=1;

        Perso[i]->attaque_ou_surplace=0;

        Perso[i]->affichage->position_pixel_colonne=120*(i+1);
        Perso[i]->affichage->position_pixel_ligne=120*(i+1);
        Perso[i]->affichage->direction= 0;
        if(i==3) {Perso[i]->affichage->direction= 1; }



        Perso[i]->affichage->colonne_tab= (120*(i+1))/taille_carre;
        Perso[i]->affichage->ligne_tab= (120*(i+1))/taille_carre;

        for (int j=0;j<4;j++)
        {
            Perso[i]->Sort[j].portee_sort=(j+5);
            Perso[i]->Sort[j].portee_sort_moins=(j+2);
            Perso[i]->Sort[j].puissance_sort= j+1;
        }
    }
    strcpy(Perso[0]->Sort[0].nom_sort,"Guerison"); // plus 5 Pv
    Perso[0]->Sort[0].portee_sort=0;
    Perso[0]->Sort[0].portee_sort_moins=0;
    strcpy(Perso[0]->Sort[1].nom_sort,"Sabotage"); // Point attaque adverse /2
    strcpy(Perso[0]->Sort[2].nom_sort,"Fugitif"); // Pm x 2
    Perso[0]->Sort[2].portee_sort=0;
    Perso[0]->Sort[2].portee_sort_moins=0;
    strcpy(Perso[0]->Sort[3].nom_sort,"Empoisonnement"); // -2 Pv chaque tour adversaire

    strcpy(Perso[1]->Sort[0].nom_sort,"Invincible"); // 0 degats pour 1 tour
    Perso[1]->Sort[0].portee_sort=0;
    Perso[1]->Sort[0].portee_sort_moins=0;
    strcpy(Perso[1]->Sort[1].nom_sort,"Etourdissement");
    strcpy(Perso[1]->Sort[2].nom_sort,"Instinct de survie");
    Perso[1]->Sort[2].portee_sort=0;
    Perso[1]->Sort[2].portee_sort_moins=0;
    strcpy(Perso[1]->Sort[3].nom_sort,"Furie");
    Perso[1]->Sort[3].portee_sort=0;
    Perso[1]->Sort[3].portee_sort_moins=0;

    strcpy(Perso[2]->Sort[0].nom_sort,"Longue distance");// Portee sort x2
    Perso[2]->Sort[0].portee_sort=0;
    Perso[2]->Sort[0].portee_sort_moins=0;
    strcpy(Perso[2]->Sort[1].nom_sort,"Paralysie");
    strcpy(Perso[2]->Sort[2].nom_sort,"Extraction");
    strcpy(Perso[2]->Sort[3].nom_sort,"Brise Glace");

    strcpy(Perso[3]->Sort[0].nom_sort,"Instinct de survie");
    Perso[3]->Sort[0].portee_sort=0;
    Perso[3]->Sort[0].portee_sort_moins=0;
    strcpy(Perso[3]->Sort[1].nom_sort,"Brouillard");
    strcpy(Perso[3]->Sort[2].nom_sort,"Paralysie");
    strcpy( Perso[3]->Sort[3].nom_sort,"Furie");
    Perso[3]->Sort[3].portee_sort=0;
    Perso[3]->Sort[3].portee_sort_moins=0;


    Perso[0]->Sort[0].id= 1;//"Guerison");
    Perso[0]->Sort[1].id=2; //"Sabotage");
    Perso[0]->Sort[2].id=3; //"Fugitif");
    Perso[0]->Sort[3].id=4 ; //"Empoisonnement");

    Perso[1]->Sort[0].id=5; //"Invincible");
    Perso[1]->Sort[1].id=9;// Etoudirdissement
    Perso[1]->Sort[2].id=7;//"Instinct de survie");
    Perso[1]->Sort[3].id=8 ; //"Furie");

    Perso[2]->Sort[0].id=6;// Longue distance
    Perso[2]->Sort[1].id=10;// Paralysie
    Perso[2]->Sort[2].id=11;// Extraction
    Perso[2]->Sort[3].id=12;// Switch

    Perso[3]->Sort[0].id=7; //"Instinct survie ");
    Perso[3]->Sort[1].id=13;//"Brouillard ");
    Perso[3]->Sort[2].id=10;//"Paralisie");
    Perso[3]->Sort[3].id=8 ;//"Furie");


}



void reinitalisation_personnages(t_personnage* Perso[4],int terrain[30][44],BITMAP*echequier,BITMAP*collision)
{
    int taille_carre=660/30;

    for (int a=0; a<30; a++)
    {
        for (int b=0; b<44; b++)
        {
            int c=0;
            c=(int)getpixel(collision,taille_carre*b+11, taille_carre*a+ 11) ;
            if (c==makecol(127,127,127))
            {
               rectfill(echequier,  taille_carre*b,   taille_carre*a,  taille_carre*(b+1), taille_carre*(a+1),makecol(0,0,255));
            }
            else if (c!=0)
            {
                rectfill(echequier,  taille_carre*b,   taille_carre*a,  taille_carre*(b+1), taille_carre*(a+1),c);
            }
            else
            {
                if ((b%2==0))
                {
                    if (a%2==0)
                    {
                        rectfill(echequier,  taille_carre*b,   taille_carre*a,  taille_carre*(b+1), taille_carre*(a+1), makecol(255,255,255));
                    }
                    else
                    {
                        rectfill(echequier,  taille_carre*b,   taille_carre*a,  taille_carre*(b+1), taille_carre*(a+1), makecol(0,0,0));
                    }
                }
                else
                {
                    if (a%2==0)
                    {
                        rectfill(echequier,  taille_carre*b,   taille_carre*a,  taille_carre*(b+1), taille_carre*(a+1), makecol(0,0,0));
                    }
                    else
                    {
                        rectfill(echequier,  taille_carre*b,   taille_carre*a,  taille_carre*(b+1), taille_carre*(a+1), makecol(255,255,255));
                    }
                }
            }
            c=(int)getpixel(echequier,taille_carre*b+11, taille_carre*a+ 11) ;
            terrain[a][b]=c;
        }
    }

    for (int i=0;i<4;i++)
    {
        Perso[i]->Pa=10;
        Perso[i]->Pm=10;
        Perso[i]->sort_actif_degatif=0;
        Perso[i]->sort_actif_positif=0;
        Perso[i]->compteur_sort_boost=0;
        Perso[i]->compteur_sort_entrave=0;

        Perso[i]->parametre_avant_sort=0;

        Perso[i]->fin_sort_boost=0;
        Perso[i]->fin_sort_entrave=0;

        Perso[i]->Pm=20;

        Perso[i]->Pv=50;
        Perso[i]->portee_attaque=3;
        Perso[i]->classe=1;

        Perso[i]->attaque_ou_surplace=0;

        Perso[i]->affichage->position_pixel_colonne=120*(i+1);
        Perso[i]->affichage->position_pixel_ligne=120*(i+1);
        Perso[i]->affichage->direction= 0;
        if(i==3) {Perso[i]->affichage->direction= 1; }

        Perso[i]->affichage->colonne_tab= (120*(i+1))/taille_carre;
        Perso[i]->affichage->ligne_tab= (120*(i+1))/taille_carre;
    }

}



void bitmap_loading(t_personnage* Perso[4],BITMAP* Ecran[8],BITMAP*Choisir[8],BITMAP* Choice[4])
{

    for (int i=0; i<36; i++)
    {
       Perso[0]->affichage->surplace[i]=create_bitmap(40,56);
       Perso[0]->affichage->surplace[i]=recup_sprites(load_bitmap("Image/One_piece/Luffy_stay2.bmp",NULL),40,56,0,0,36,i);
    }

    Perso[0]->affichage->indice_animation_surplace=36;
    Perso[0]->affichage->difference_deposX=-40;
    Perso[0]->affichage->difference_deposY=-5; // faire -


     for (int i=0; i<6; i++)
    {

       Perso[0]->affichage->attaque[i]=create_bitmap(133,56);
       Perso[0]->affichage->attaque[i]=recup_sprites(load_bitmap("Image/One_piece/Luffy_attaque.bmp",NULL),133,56,0,0,6,i);
    }

    Perso[0]->affichage->indice_animation_attaque=6;
    Perso[0]->affichage->surplace_taillex=40;
    Perso[0]->affichage->surplace_tailley=47;
    Perso[0]->affichage->attaque_taillex=137;
    Perso[0]->affichage->attaque_tailley=47;
    strcpy(Perso[0]->nom,"Luffy");


    for (int i=0; i<15; i++)
    {
        Perso[1]->affichage->surplace[i]=create_bitmap(217,68);
        Perso[1]->affichage->surplace[i]=recup_sprites(load_bitmap("Image/Bleach/ichigo_stay.bmp",NULL),217,68,0,0,15,i);
    }

    Perso[1]->affichage->indice_animation_surplace=15;


    for (int i=0; i<19; i++)
    {
        Perso[1]->affichage->attaque[i]=create_bitmap(400,293);
        Perso[1]->affichage->attaque[i]=recup_sprites(load_bitmap("Image/Bleach/ichigo_attaque.bmp",NULL),400,293,0,0,19,i);
    }

    Perso[1]->affichage->indice_animation_attaque=19;
    Perso[1]->affichage->difference_deposX=-100;
    Perso[1]->affichage->difference_deposY=-45; // faire -

    Perso[1]->affichage->surplace_taillex=225;
    Perso[1]->affichage->surplace_tailley=63;
    Perso[1]->affichage->attaque_taillex=400;
    Perso[1]->affichage->attaque_tailley=293;

    strcpy(Perso[1]->nom,"Ichigo");

    for (int i=0; i<18; i++)
    {
       Perso[2]->affichage->surplace[i]=create_bitmap(101,84);
       Perso[2]->affichage->surplace[i]=recup_sprites(load_bitmap("Image/Danjo/Danjo_stay1.bmp",NULL),101,84,0,0,18,i);
    }

    Perso[2]->affichage->indice_animation_surplace=10;

     for (int i=0; i<13; i++)
    {

       Perso[2]->affichage->attaque[i]=create_bitmap(147,105);
       Perso[2]->affichage->attaque[i]=recup_sprites(load_bitmap("Image/Danjo/Danjo_attaque.bmp",NULL),147,105,0,0,13,i);
    }

    Perso[2]->affichage->indice_animation_attaque=13;
    Perso[2]->affichage->difference_deposX=20;
    Perso[2]->affichage->difference_deposY=20; // faire -

    Perso[2]->affichage->surplace_taillex=75;
    Perso[2]->affichage->surplace_tailley=80;
    Perso[2]->affichage->attaque_taillex=80;
    Perso[2]->affichage->attaque_tailley=80;

    strcpy(Perso[2]->nom,"Danjo");



    for (int i=0; i<30; i++)
    {

       Perso[3]->affichage->surplace[i]=create_bitmap(103,101);
       Perso[3]->affichage->surplace[i]=recup_sprites(load_bitmap("Image/Monster/Monster_stay2.bmp",NULL),103,101,0,0,30,i);
    }

    Perso[3]->affichage->indice_animation_surplace=30;

     for (int i=0; i<26; i++)
    {

       Perso[3]->affichage->attaque[i]=create_bitmap(125,120);
       Perso[3]->affichage->attaque[i]=recup_sprites(load_bitmap("Image/Monster/Monster_attaque2n.bmp",NULL),125,120,0,0,26,i);
    }

    Perso[3]->affichage->indice_animation_attaque=26;
    Perso[3]->affichage->difference_deposX=5;
    Perso[3]->affichage->difference_deposY=5; // faire - et a appliquer sur les ccordonnes de l'attaque
    Perso[3]->affichage->surplace_taillex=103;
    Perso[3]->affichage->surplace_tailley=76 ;
    Perso[3]->affichage->attaque_taillex=125;
    Perso[3]->affichage->attaque_tailley=95;

    strcpy(Perso[3]->nom,"Monster");

    for (int i=0;i<4;i++)
    {
        Perso[i]->affichage->ancienne_couleur=-1;
    }

   char fichier[500];

    for (int i=0; i<8; i++)
    {
        sprintf(fichier,"Image/Acceuil/frame_%d_delay-0.1s.bmp",i);
        Ecran[i]=chargerImage(fichier);
    }

    for (int i=0; i<8; i++)
    {
       Choisir[i]=create_bitmap(1080,680);
       Choisir[i]=recup_sprites(load_bitmap("Image/Choisir.bmp",NULL),1080,680,0,0,8,i);
    }
    for (int i=0; i<4; i++)
    {
       Choice[i]=create_bitmap(1080,680);
    }
    Choice[0]=load_bitmap("Image/Luffy.bmp",NULL);
    Choice[1]=load_bitmap("Image/Ichigo.bmp",NULL);
    Choice[2]=load_bitmap("Image/Django.bmp",NULL);
    Choice[3]=load_bitmap("Image/Montre.bmp",NULL);

}



void init_echequier(BITMAP* echequier, t_personnage* Perso[4],int taille_carre,int terrain[30][44])
{
    for (int type=0; type<4; type++)
    {
        int ligne=Perso[type]->affichage->position_pixel_ligne;
        int colonne=Perso[type]->affichage->position_pixel_colonne;

        if ((terrain[ligne/taille_carre][colonne/taille_carre]!=makecol(0,0,255))&&(terrain[ligne/taille_carre][colonne/taille_carre]!=makecol(0,100,255)))
        {
            if ( Perso[type]->affichage->ancienne_couleur!=-1)
            {
                terrain[Perso[type]->affichage->position_pixel_ligne/taille_carre][Perso[type]->affichage->position_pixel_colonne/taille_carre]=Perso[type]->affichage->ancienne_couleur;
            }
            Perso[type]->affichage->ancienne_couleur=terrain[ligne/taille_carre][colonne/taille_carre];
            terrain[ligne/taille_carre][colonne/taille_carre]=makecol(0,100,255);
            Perso[type]->affichage->position_pixel_ligne=ligne;
            Perso[type]->affichage->position_pixel_colonne=colonne;

        }
    }

    for ( int i=0; i<30; i++)
    {
        for (int j=0; j<44; j++)
        {
            rectfill(echequier,  taille_carre*j,   taille_carre*i,  taille_carre*(j+1), taille_carre*(i+1),terrain[i][j]);
        }
    }

}

