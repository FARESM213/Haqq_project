#include"header.h"

void choix_action(BITMAP* collision,int* choix,int*confirm)
{
    if((mouse_b&1)&&(mouse_x>970))
    {
        while(mouse_b&1);
        if((int)getpixel(collision,mouse_x,mouse_y)==(int)(makecol(255,254,145)))
        {
            (*choix)= 1 ;
        } // Attaquer}
        if((int)getpixel(collision,mouse_x,mouse_y)==(int)makecol(0,123,176))
        {
            (*choix)= 2 ;     //Deplacement
        }
        if((int)getpixel(collision,mouse_x,mouse_y)==(int)makecol(127,130,187))
        {
            (*choix)= 3 ;     // Annuler
            (*confirm)=1;
        }
        if((int)getpixel(collision,mouse_x,mouse_y)==(int)makecol(237,28,36))
        {
            (*choix)= 4;     //Sort1
        }
        if((int)getpixel(collision,mouse_x,mouse_y)==(int)makecol(153,217,234))
        {
            (*choix)= 5 ;     //Sort2
        }
        if((int)getpixel(collision,mouse_x,mouse_y)== (int)makecol(201,255,32) )
        {
            (*choix)= 6 ;     //Sort3
        }
        if((int)getpixel(collision,mouse_x,mouse_y)==(int)makecol(255,201,14))
        {
            (*choix)= 7 ;     //Sort4
        }
        while(mouse_b&1);
    }
}

void execute_action(int* B, BITMAP* attack,BITMAP*echequier, BITMAP*buffer,BITMAP*Mapp, t_personnage* Perso[4], int type, int taille_carre, int terrain[30][44],int* confirm)
{
    switch(*(B))
    {
    case 1 :
    {
        blit(attack,screen,0,0,0,0,1080,670);
        attaquer(Perso,terrain,type,taille_carre,B,confirm);
    }
    break;
    case 2 :
    {
        placement(echequier,taille_carre,terrain,Perso,type,buffer,Mapp,B,confirm);
    }
    break;
    case 3 :
    {
    }
    break;
    default :
    {
        sortilege(echequier,taille_carre,terrain,Perso,type,buffer,Mapp,B,confirm);
    }
    break;
    case 0 :
    { } break;

    }

}

/*void bonus(int terrain[30][44],t_personnage* Perso[4])
{
    for (int i=0; i<4; i++)
    {
        int color= terrain[Perso[i]->affichage->ligne_tab][Perso[i]->affichage->colonne_tab];
        if ((int)color==(int)makecol(236,0,4)) {   } // Attaque
        else if ((int)color==(int)makecol(0,163,232)) {   } // PM
        else if ((int)color==(int)makecol(200,191,231)) {   } // Mouvement
        else if ((int)color==(int)makecol(255,174,201)) {   } // + attaque
        else if ((int)color==(int)makecol(200,255,32)) {   } // PV
    }
}*/

int victoire( t_personnage* Perso[4],int* vainqueur,int mort_perso[4],int perso_choisi[4])
{
    int retour=0;
    for (int i=0; i<4; i++)
    {
        if (Perso[i]->Pv<=0)
        {
            mort_perso[retour]=i;
            retour++;
        }
        else
        {
            for (int j=0;j<4;j++)
            {
                if(i==perso_choisi[j])
                {
                    *(vainqueur)=i;
                }
            }
        }
    }
    return retour;
}

void choix_perso(BITMAP* Choisir[8],BITMAP* Choice[4],t_personnage*Perso[4],BITMAP*buffer,int compteur,int perso_choisi[4],int* nbr_joueurs)
{
    int test=0;
    int confirm=0;
    *(nbr_joueurs)=2;
    do
    {
        if ((*(nbr_joueurs)<2)||(*(nbr_joueurs)>4))
        {
            allegro_message("Veuillez entrer un chiffre correct");
        }
        allegro_message("Entrez le nombre de joueur ( 2-4 )");
        clear_keybuf();
        *(nbr_joueurs)=(readkey()&0xFF)-48;

    }
    while ((*(nbr_joueurs)<2)||(*(nbr_joueurs)>4));

    int joueur[*(nbr_joueurs)];
    for (int i=0; i<*nbr_joueurs; i++)
    {
        joueur[i]=-1;
    }
    while(confirm<*nbr_joueurs)
    {
        blit(Choisir[compteur%8],buffer,0,10,0,0,1080,670);
        if(( mouse_x>=200 && mouse_x <350) && (mouse_y>=200 && mouse_y<=450))
        {
            rectfill(buffer, 200, 200, 350, 450, makecol(255,255,255));
            if(mouse_b&1)
            {
                while (mouse_b&1);
                int trouve=0;
                for (int i=0; i<*nbr_joueurs; i++)
                {
                    if(joueur[i]==0)
                    {
                        trouve=1;
                    }
                }
                if(trouve==0)
                {
                    joueur[confirm]=0;
                    confirm++;
                }
                else
                {
                    allegro_message("Ce joueur est deja selectionne \n veuillez en chosir un autre ");
                }
            }
        }
        else
        {
            rect(buffer, 200, 200, 350, 450, makecol(255,255,255));
        }
        if(( mouse_x>=400 && mouse_x <550) && (mouse_y>=200 && mouse_y<=450))
        {
            rectfill(buffer, 400, 200, 550, 450, makecol(255,255,255));
            if(mouse_b&1)
            {
                while (mouse_b&1);
                int trouve=0;
                for (int i=0; i<*nbr_joueurs; i++)
                {
                    if(joueur[i]==1)
                    {
                        trouve=1;
                    }
                }
                if(trouve==0)
                {
                    joueur[confirm]=1;
                    confirm++;
                }
                else
                {
                    allegro_message("Ce joueur est deja selectionne \n veuillez en chosir un autre ");
                }
            }
        }
        else
        {
            rect(buffer, 400, 200, 550, 450, makecol(255,255,255));
        }
        if(( mouse_x>=600 && mouse_x <750) && (mouse_y>=200 && mouse_y<=450))
        {
            rectfill(buffer, 600, 200, 750, 450, makecol(255,255,255));
            if(mouse_b&1)
            {
                while (mouse_b&1);
                int trouve=0;
                for (int i=0; i<*nbr_joueurs; i++)
                {
                    if(joueur[i]==2)
                    {
                        trouve=1;
                    }
                }
                if(trouve==0)
                {
                    joueur[confirm]=2;
                    confirm++;
                }
                else
                {
                    allegro_message("Ce joueur est deja selectionne \n veuillez en chosir un autre ");
                }
            }
        }
        else
        {
            rect(buffer, 600, 200, 750, 450, makecol(255,255,255));
        }
        if(( mouse_x>=800 && mouse_x <950) && (mouse_y>=200 && mouse_y<=450))
        {
            rectfill(buffer, 800, 200, 950, 450, makecol(255,255,255));
            if(mouse_b&1)
            {
                while (mouse_b&1);
                int trouve=0;
                for (int i=0; i<*nbr_joueurs; i++)
                {
                    if(joueur[i]==3)
                    {
                        trouve=1;
                    }
                }
                if(trouve==0)
                {
                    joueur[confirm]=3;
                    confirm++;
                }
                else
                {
                    allegro_message("Ce joueur est deja selectionne \n veuillez en chosir un autre ");
                }
            }
        }
        else
        {
            rect(buffer, 800, 200, 950, 450, makecol(255,255,255));
        }
        if (compteur%20==0)
        {
            test++;
        }

        for (int i=0; i<*nbr_joueurs; i++)
        {
            if(joueur[i]!=-1)
            {
                rectfill(buffer, 200*(joueur[i]+1), 200, 200*(joueur[i]+1)+150, 450, makecol(255,40,40));
            }
        }
        for (int i=0; i<4; i++)
        {
            textprintf_ex(buffer, font,200*(i+1)+50,250, makecol(0,0,0),-1, "%s",Perso[i]->nom);
            if((i==3)||(i==2))
                draw_sprite(buffer,Perso[i]->affichage->surplace[test%Perso[i]->affichage->indice_animation_surplace],200*(i+1)+20,300);
            else if(i==1)
                draw_sprite(buffer,Perso[i]->affichage->surplace[test%Perso[i]->affichage->indice_animation_surplace],200*(i+1)-20,300);
            else
                draw_sprite(buffer,Perso[i]->affichage->surplace[test%Perso[i]->affichage->indice_animation_surplace],200*(i+1)+50,300);

        }
        show_mouse(buffer);
        blit(buffer,screen,0,0,0,0,1080,670);
        compteur++;
    }
    for (int i=0; i<*nbr_joueurs; i++)
    {
        perso_choisi[i]=joueur[i];
    }

}


void Menu(BITMAP* Ecran[8],int perso_choisi[4],int* choix, int compteur,BITMAP *buffer,t_personnage* Perso[4], BITMAP* Choisir[8],BITMAP* Choice[4],int* nbr_joueurs,int* rejouer)
{
    if(compteur%50==0)
    {
        blit(Ecran[compteur%8],buffer,0,10,0,0,1080,670);
    }
    if (((mouse_x >= 125 && mouse_x <= 325) &&( mouse_y>=100 && mouse_y <= 200))||*(rejouer)==1)
    {
        rectfill(buffer,125,100,325,200,makecol(255,255,255));
        if((mouse_b&1)||*(rejouer)==1)
        {
            while(mouse_b&1);
            choix_perso(Choisir,Choice,Perso,buffer,compteur,perso_choisi,nbr_joueurs);
            *(choix)=2;
            *(rejouer)=0;
        }
    }
    else
    {
        rectfill(buffer,125,100,325,200,makecol(255,55,47));
    }
    if ((mouse_x >= 425 && mouse_x <= 625) &&( mouse_y>=100 && mouse_y <= 200))
    {
        rectfill(buffer,425,100,625,200,makecol(255,255,255));
        if(mouse_b&1)
        {
            while(mouse_b&1);
            *(choix)=3;
        }
    }
    else
    {
        rectfill(buffer,425,100,625,200,makecol(0,125,255));
    }

    if ((mouse_x >= 725 && mouse_x <= 925) &&( mouse_y>=100 && mouse_y <= 200))
    {
        rectfill(buffer,725,100,925,200,makecol(255,255,255));
        if(mouse_b&1)
        {
            while(mouse_b&1);
            *(choix)=0;
        }
    }
    else
    {
        rectfill(buffer,725,100,925,200,makecol(22,184,78));
    }
    textprintf_ex(buffer, font,200,150, makecol(0,0,0),-1, " JOUER ");
    textprintf_ex(buffer, font,500,150, makecol(0,0,0),-1, " REGLES ");
    textprintf_ex(buffer, font,800,150, makecol(0,0,0),-1, " QUITTER ");

    show_mouse(buffer);
    blit(buffer,screen,0,0,0,0,1080,670);
}

void Regle(BITMAP* buffer,BITMAP* Choice[4],int e, int*choix,t_personnage* Perso[4],int a)
{
    int oow=0;
    int test=0;
    while (!key[KEY_ESC])
    {
        oow++;
        if(oow%20==0)
        {
            test++;
        }
        clear(buffer);
        if (key[KEY_RIGHT])
        {
            if (e<3)
            {
                e++;
                while(key[KEY_RIGHT]);
            }
        }
        else if (key[KEY_LEFT])
        {
            if (e>0)
                e--;
            while (key[KEY_LEFT]);
        }
        draw_sprite(buffer,Choice[e],0,0);

        textprintf_ex(buffer, font,200*(1)+50,250, makecol(0,0,0),-1, "%s",Perso[e]->nom);
        if((e==3)||(e==2))
            draw_sprite(buffer,Perso[e]->affichage->surplace[test%Perso[e]->affichage->indice_animation_surplace],130*(1)+15,130);
        else if(e==1)
            draw_sprite(buffer,Perso[e]->affichage->surplace[test%Perso[e]->affichage->indice_animation_surplace],130*(1)-40,140);
        else
            draw_sprite(buffer,Perso[e]->affichage->surplace[test%Perso[e]->affichage->indice_animation_surplace],130*(1)+40,150);

        blit(buffer,screen,0,0,0,0,1080,670);

    }
    if (key[KEY_ESC])
    {
        *(choix)=1;
        clear(buffer);
    }

}
