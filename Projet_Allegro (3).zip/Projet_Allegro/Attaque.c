#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include<allegro.h>
#include <time.h>
#include"header.h"
#include <stdbool.h>


bool value_in(int choix, int ennemi[4])
{
    for (int i = 0; i < 4; i++)
    {
        if (ennemi[i]==choix)
            return true;
    }
    return false;
}
void attaquer(t_personnage* Perso[4],int terrain[30][44], int type,int taille_carre,int*f,int*confirm)
{
    int ligne=Perso[type]->affichage->ligne_tab;
    int colonne=Perso[type]->affichage->colonne_tab;

    int ennemi[3]= {-1,-1,-1};
    int j=0;
    for (int i=0; i<4; i++)
    {
        if(i!=type)
        {
            if ((abs(Perso[i]->affichage->ligne_tab-ligne)<=1)&&(abs(Perso[i]->affichage->colonne_tab-colonne)<=1)&&(Perso[i]->Pv>0))
            {
                ennemi[j]=i;
                j++;
            }
        }
    }
    if (Perso[type]->Pa<2)
    {
        allegro_message("Nombre de Pa Insuffisant");
        (*f)=0;
    }
    else
    {
        if (j>0)
        {
            char liste[500]="Voici la liste des ennemis potentiels a attaquer : \n\n";
            char nombre[2]=" ";
            char PV[2]=" ";

            for (int f=0; f<j; f++)
            {
                strcat(liste,"\t ");
                sprintf(nombre,"%d",ennemi[f]);
                strcat(liste,nombre);

                strcat(liste,". ");
                strcat(liste,Perso[ennemi[f]]->nom);

                strcat(liste," | PV : ");
                sprintf(PV,"%d",Perso[ennemi[f]]->Pv);
                strcat(liste,PV);
                strcat(liste,"\n\n");
            }
            strcat(liste,"Entrez le numero de l'ennemi a attaquer ( ou ESC pour annuler ) ");
            int choix= -1; //pour stocker les chiffres
            do
            {
                allegro_message(liste);
                clear_keybuf();
                choix=(readkey()&0xFF);
                if (key[KEY_ESC])
                {
                }
                else
                {
                    choix=choix-48; //pour avoir directement les chiffres
                    if(!value_in(choix,ennemi))
                    {
                        allegro_message("Entrez un nombre correct ! ");
                    }
                    else
                    {
                        char attaque[500]="Confirmez vous ce choix d'attaque ? : ";
                        strcat(attaque," ");
                        strcat(attaque,Perso[type]->nom);
                        strcat(attaque," attaque ");
                        strcat(attaque,Perso[choix]->nom);
                        strcat(attaque," \n\n Appuyez ENTER pour confirmer ou ESC pour annuler ");
                        allegro_message(attaque);
                        do
                        {

                        }
                        while ((!key[KEY_ENTER])&&(!key[KEY_ESC]));
                        if (key[KEY_ESC])
                        {
                            choix=500;
                            allegro_message("Attaque Annulee \n");
                            while(key[KEY_ESC]);
                        }
                        else
                        {
                            allegro_message("Attaque confirmee\n");
                            int alea= rand()%(10-1+1)+1;
                            printf("%d \n", alea);
                            if((Perso[choix]->affichage->colonne_tab)-(Perso[type]->affichage->colonne_tab)==-1)
                            {
                                Perso[type]->affichage->direction=1;
                            }
                            else
                            {
                                Perso[type]->affichage->direction=0;
                            }

                            if (alea==9)
                            {
                                allegro_message("Dommage, vous avez rater l'attaque ");
                            }
                            else
                            {
                                Perso[type]->Pa-=2;
                                printf(" %d  ",Perso[choix]->sort_actif_positif);
                                if (Perso[choix]->sort_actif_positif==5)
                                {
                                    allegro_message(" Le Personnage attaque possede un sort d'invincibilit� pour ce tour ");
                                }
                                else
                                {
                                    if (Perso[type]->sort_actif_positif==8)
                                    {
                                        Perso[choix]->Pv-=20;
                                    }
                                    else
                                    {
                                        Perso[choix]->Pv-=5;
                                    }

                                    if( Perso[choix]->Pv<=0)
                                    {
                                         terrain[Perso[choix]->affichage->position_pixel_ligne/taille_carre][Perso[choix]->affichage->position_pixel_colonne/taille_carre]=Perso[choix]->affichage->ancienne_couleur;
                                    }
                                }
                                Perso[type]->attaque_ou_surplace=1;
                            }
                            *(confirm)=1;
                        }
                    }
                }
            }
            while ((!value_in(choix,ennemi))&&(choix!=500)&&(!key[KEY_ESC]));
            while(key[KEY_ESC]);
            *(f)=0;
        }
        else
        {
            allegro_message("Aucun ennemi a attaquer ! ");
            (*f)=0;
        }
    }

}

