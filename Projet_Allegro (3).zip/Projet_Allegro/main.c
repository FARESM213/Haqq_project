#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdlib.h>
#include<allegro.h>
#include "header.h"
#include <time.h>



int Ecran_victoire(BITMAP* Ranking, int mort_perso[4],BITMAP*buffer,t_personnage*Perso[4],int * rejouer,int vainqueur,int nbr_joueurs)
{
    int choix=0;

    while(choix==0)
    {

        clear(buffer);
        blit(Ranking,buffer,0,0,0,0,1080,670);

        if ((mouse_x >= 125 && mouse_x <= 325) &&( mouse_y>=50 && mouse_y <= 150))
        {
            rectfill(buffer,125,50,325,150,makecol(255,255,255));
            if(mouse_b&1)
            {
                choix=2;
                (*rejouer)=0;
                while(mouse_b&1);
            }
        }
        else
        {
            rectfill(buffer,125,50,325,150,makecol(255,55,47));
        }
        if ((mouse_x >= 425 && mouse_x <= 625) &&( mouse_y>=50 && mouse_y <= 150))
        {
            rectfill(buffer,425,50,625,150,makecol(255,255,255));
            if(mouse_b&1)
            {
                choix=1;
                while(mouse_b&1);
                (*rejouer)=1;
            }
        }
        else
        {
            rectfill(buffer,425,50,625,150,makecol(0,125,255));
        }

        if ((mouse_x >= 725 && mouse_x <= 925) &&( mouse_y>=50 && mouse_y <= 150))
        {
            rectfill(buffer,725,50,925,150,makecol(255,255,255));
            if(mouse_b&1)
            {
                while(mouse_b&1);
                choix=1;
            }
        }
        else
        {
            rectfill(buffer,725,50,925,150,makecol(22,184,78));
        }

        textprintf_ex(buffer, font,200,100, makecol(0,0,0),-1, " REJOUER ");
        textprintf_ex(buffer, font,450,100, makecol(0,0,0),-1, " NOUVELLE PARTIE ");
        textprintf_ex(buffer, font,800,100, makecol(0,0,0),-1, " QUITTER ");


        rectfill(buffer,450,530,650,630,makecol(0,0,0));

        textprintf_ex(buffer, font,480,540, makecol(255,255,255),-1, "RANKING OF KINGS ");

        textprintf_ex(buffer, font,500,560, makecol(255,255,0),-1, "1. %s ",Perso[vainqueur]->nom);

        for (int i=nbr_joueurs; i>=0; i--)
        {
            if(mort_perso[i]!=-1)
            {
                textprintf_ex(buffer, font,500,540+(20*(3-i)), makecol(255,255,0),-1, "%d. %s ",3-i,Perso[mort_perso[i]]->nom);
            }
        }

        show_mouse(buffer);
        blit(buffer,screen,0,0,0,0,1080,670);
    }

    return choix;

}


int main()
{
    t_personnage* Perso[4];
    BITMAP* collision;
    BITMAP* Mapp;
    BITMAP* buffer;
    BITMAP* Deplacement;
    allegro_init();
    install_keyboard();
    install_mouse();
    srand(time(NULL));
    set_color_depth(32);
    if (set_gfx_mode(GFX_AUTODETECT_WINDOWED,1080,670,0,0)!=0)
    {
        allegro_message("probleme gfx mode");
        allegro_exit();
        exit(EXIT_FAILURE);
    }

    int terrain[30][44];
    BITMAP* echequier= create_bitmap(1080,670);
    collision=create_bitmap(SCREEN_W,SCREEN_H);
    Mapp=create_bitmap(1080,670);
    buffer=create_bitmap(1080,670);
    Deplacement=create_bitmap(1080,670);
    rectfill(Deplacement,0,0,1080,670,makecol(0,0,0));
    BITMAP* attack=load_bitmap("Image/Attack.bmp",NULL);

    Mapp=load_bitmap("Image/Map2.bmp",NULL);
    int taille_carre=660/30;
    for(int i = 0 ; i < 45 ; i++ )
    {
        line(Mapp,taille_carre*i,0,taille_carre*i,800,makecol(150,150,150));
        line(Mapp,0,taille_carre*i,968,taille_carre*i,makecol(150,150,150));
    }
    collision=load_bitmap("Image/Collision.bmp",NULL);
    BITMAP* Ranking=load_bitmap("Image/Ranking.bmp",NULL);;
    initalisation_personnages(Perso,terrain,echequier,collision);
    BITMAP* Ecran[8];
    BITMAP* Choice[4];
    BITMAP* Choisir[8];

    bitmap_loading(Perso,Ecran,Choisir,Choice);

    const int vitess_ordi=10;

    int i=0; // compteur pour images
    int j=0; // compteur pour vitesse des images
    int type=2;
    int c=0;
    int joueur=0;
    int vainqueur=-1;
    init_echequier(echequier,Perso,taille_carre,terrain);
    int fin_de_jeu=0;
    int nbr_joueurs=4;
    int e=0;
    int choix=-1;
    int compteur=0;
    int Perso_choisi[4]= {-1,-1,-1,-1};
    int mort_perso[4]= {-1,-1,-1,-1};
    int rejouer=0;
    while (choix!=0)
    {
        for (int p=0; p<4; p++)
        {
            Perso_choisi[p]= -1;
        }

        Menu(Ecran,Perso_choisi,&choix,compteur,buffer,Perso,Choisir,Choice,&nbr_joueurs,&rejouer);
        compteur++;
        while (choix==3)
        {
            Regle(buffer,Choice,e,&choix,Perso,compteur);
        }
        while(choix==2)
        {
            for (joueur=0; joueur<nbr_joueurs; joueur++)
            {
                int confirm=0;
                type=Perso_choisi[joueur];
                if (Perso[type]->Pv>0)
                {
                    clock_t begin;
                    double compte_a_rebours=0;;
                    begin = clock();
                    while(confirm==0)
                    {
                        if (Perso[type]->sort_actif_degatif==9)
                        {
                            allegro_message(" %s est etourdie pendant ce tour, Il ne peut donc rien faire ",Perso[type]->nom);
                            confirm=1;
                        }
                        else
                        {
                            clear(buffer);
                            blit(Mapp,buffer,0,0,0,0,1080,670);
                            if (key[KEY_L])
                            {
                                blit(echequier,screen,0,0,0,0,1080,670);
                            }
                            if (key[KEY_O])
                            {
                                blit(collision,screen,0,0,0,0,1080,670);
                            }
                            choix_action(collision,&c,&confirm);
                            execute_action(&c, attack,echequier, buffer,Mapp, Perso, type, taille_carre,terrain,&confirm);
                            for (int a=0; a<nbr_joueurs; a++)
                            {
                                int k=Perso_choisi[a];
                                Placer_un_personnage(buffer,Perso,i,Perso[k]->attaque_ou_surplace,k,type);
                            }
                            show_mouse(buffer);
                            compte_a_rebours = (float)(clock() - begin) / CLOCKS_PER_SEC;
                            if(compte_a_rebours>15)
                            {
                                confirm=1;
                            }
                            textprintf_ex(buffer, font,990,650, makecol(255,255,255),-1, "%fs",(15-compte_a_rebours));
                            blit(buffer,screen,0,0,0,0,1080,670);
                            j++;
                            if( j%vitess_ordi==0)
                                i++;

                            if (i%20==0)
                            {
                                for(int b=0; b<4; b++)
                                {
                                    if (Perso[b]->attaque_ou_surplace==1)
                                    {
                                        Perso[b]->affichage->conteur_attaque++;
                                    }
                                }
                            }
                            for (int m=0; m<4; m++)
                            {
                                if ((Perso[m]->affichage->conteur_attaque)%50==49)
                                {
                                    Perso[m]->attaque_ou_surplace=0;
                                    Perso[m]->affichage->conteur_attaque=0;
                                }
                            }

                            for ( int z=0; z<30; z++)
                            {
                                for (int y=0; y<44; y++)
                                {
                                    rectfill(echequier,  taille_carre*y,   taille_carre*z,  taille_carre*(y+1), taille_carre*(z+1),terrain[z][y]);
                                }
                            }
                        }
                        if(key[KEY_ESC])
                        {
                            allegro_message("Appuiyez Entrer pour quitter la partie");
                            int oui=0;
                            do
                            {
                                oui=readkey()&0xFF;
                                if(key[KEY_ENTER])
                                {
                                    choix=1;
                                    reinitalisation_personnages(Perso,terrain,echequier,collision);
                                    break;
                                }
                            }
                            while(oui==27);
                        }
                        if(choix==1)
                            break;
                    }
                    if(choix==1)
                        break;
                }
                fin_de_jeu=victoire(Perso,&vainqueur,mort_perso,Perso_choisi);
            }
            Degats_Boost(Perso);
            if( fin_de_jeu == nbr_joueurs-1)
            {
                choix=Ecran_victoire(Ranking,mort_perso,buffer,Perso,&rejouer,vainqueur,nbr_joueurs);
                reinitalisation_personnages(Perso,terrain,echequier,collision);
                fin_de_jeu=0;
                for (int p=0; p<4; p++)
                {
                    mort_perso[p]= -1;
                }
            }
        }
    }
    allegro_exit();
    return 0;
}
END_OF_MAIN();
