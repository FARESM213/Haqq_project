#ifndef HEADER_H_INCLUDED
#define HEADER_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include<allegro.h>
#include <time.h>

typedef struct affichage
{
    int position_pixel_ligne;
    int position_pixel_colonne;

    int indice_animation_surplace;
    int indice_animation_attaque;
    BITMAP* surplace[500];
    BITMAP* attaque[500];

    int difference_deposX;
    int difference_deposY;

    int attaque_taillex;
    int attaque_tailley;
    int surplace_taillex;
    int surplace_tailley;

    int ancienne_couleur;
    int conteur_attaque;
    int ligne_tab;
    int colonne_tab;
    int direction;


}t_affichage;

typedef struct sortilege
{
    int puissance_sort;
    int portee_sort;
    int portee_sort_moins;
    int id;

    char nom_sort[50];

}t_sortilege;


typedef struct personnage
{
    int Pv; // Vie
    int Pm; // mouvement
    int Pa; // Attaque
    int classe; // de 1 a 4
    char nom[50];

    int portee_attaque; // en fonction de la classe, 1 ou plus.
    int attaque_ou_surplace;

    t_sortilege Sort[4];
    t_affichage* affichage;

    int sort_actif_positif;
    int sort_actif_degatif;

    int compteur_sort_boost;
    int compteur_sort_entrave;

    int fin_sort_boost;
    int fin_sort_entrave;

    int parametre_avant_sort;
    int index;

} t_personnage;



BITMAP* recup_sprites( BITMAP*scr,int w,int h,int startx,int starty,int col,int element);
BITMAP *chargerImage(char *nomFichierImage);
void initalisation_personnages(t_personnage* Perso[4],int terrain[30][44],BITMAP*echequier,BITMAP*collision);
void bitmap_loading(t_personnage* Perso[4],BITMAP* Ecran[8],BITMAP*Choisir[8],BITMAP* Choice[4]);

void placement(BITMAP* echequier,int taille_carre,int terrain[30][44],t_personnage* Perso[4], int type,BITMAP* buffer,BITMAP* Mapp,int* choix,int* confirm);
void init_echequier(BITMAP* echequier, t_personnage* Perso[4],int taille_carre,int terrain[30][44]);
void Placer_un_personnage(BITMAP* buffer, t_personnage* Perso[4], int i , int genre,int type,int type2);// indice est l'indice d'animation, attaque ou surplace // genre==0 pour place , 1 pour attaquerr;
void attaquer(t_personnage* Perso[4],int terrain[30][44], int type,int taille_carre,int *choix,int*confirm);
void surbrillance_Sort(t_personnage* Perso, BITMAP* buffer, int terrain[30][44],int *f);
void sortilege(BITMAP* echequier,int taille_carre,int terrain[30][44],t_personnage* Perso[4], int type,BITMAP* buffer,BITMAP* Mapp,int* f, int* confirm );
void sort_de_vie(t_personnage* Perso, int ajout_pv,float coefficient, int type);

void sort_d_attaque(t_personnage* Perso,float coefficient);
void sort_deplacement(t_personnage* Perso,float coefficient);
void sort_portee(t_personnage* Perso,float coefficient);
void Degats_Boost(t_personnage* Perso[4]);
void reinitalisation_personnages(t_personnage* Perso[4],int terrain[30][44],BITMAP*echequier,BITMAP*collision);


void choix_action(BITMAP* collision,int* choix,int*confirm);
void execute_action(int* B, BITMAP* attack,BITMAP*echequier, BITMAP*buffer,BITMAP*Mapp, t_personnage* Perso[4], int type, int taille_carre, int terrain[30][44],int* confirm);
void bonus(int terrain[30][44],t_personnage* Perso[4]);
int victoire( t_personnage* Perso[4],int* vainqueur,int mort_perso[4],int perso_choisi[4]);
void choix_perso(BITMAP* Choisir[8],BITMAP* Choice[4],t_personnage*Perso[4],BITMAP*buffer,int compteur,int perso_choisi[4],int* nbr_joueurs);
void Menu(BITMAP* Ecran[8],int perso_choisi[4],int* choix, int compteur,BITMAP *buffer,t_personnage* Perso[4], BITMAP* Choisir[8],BITMAP* Choice[4],int* nbr_joueurs,int *rejouer);
void Regle(BITMAP* buffer,BITMAP* Choice[4],int e, int*choix,t_personnage* Perso[4],int a);
#endif // HEADER_H_INCLUDED
