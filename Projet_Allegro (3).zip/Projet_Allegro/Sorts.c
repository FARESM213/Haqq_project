#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include<allegro.h>
#include <time.h>
#include"header.h"
#include <stdbool.h>


void surbrillance_Sort(t_personnage* Perso, BITMAP* buffer, int terrain[30][44],int *f)
{
    int taille_carre=22;
    int position_ligne_act=Perso->affichage->position_pixel_ligne/taille_carre;
    int position_ligne_col=Perso->affichage->position_pixel_colonne/taille_carre;

    if ( Perso->Sort[(*(f))-4].portee_sort==0)
    {
        rectfill(buffer,  (taille_carre*Perso->affichage->ligne_tab)+3,   (taille_carre*Perso->affichage->colonne_tab)+3,  ((taille_carre)*(Perso->affichage->ligne_tab+1))-3,  ((taille_carre)*(Perso->affichage->colonne_tab+1))-3,makecol(0,128,255));
    }
    else
    {
        for (int a=0; a<30; a++)
        {
            for (int b=0; b<44; b++)
            {
                if ((abs(position_ligne_act-a)+abs(position_ligne_col-b)<=Perso->Sort[(*(f))-4].portee_sort)&&(terrain[a][b]!=makecol(0,0,255))&&(abs(position_ligne_act-a)+abs(position_ligne_col-b)>Perso->Sort[(*(f))-4].portee_sort_moins))
                {
                    rectfill(buffer,  (taille_carre*b)+3,   (taille_carre*a)+3,  ((taille_carre)*(b+1))-3,  ((taille_carre)*(a+1))-3,makecol(0,128,255));
                }
            }
        }
    }

}


void Sort(t_personnage* Victime, t_personnage* Assaillant, t_sortilege sort_applique)
{
    int alea= rand()%(8-1+1)+1;

    if (alea%7==0)
    {

        allegro_message("Vous venez de manquer votre Sort...");
    }
    else
    {
        int id=sort_applique.id;
        switch(id)
        {
        case 1 :
        {
            sort_de_vie(Assaillant,10,0,0);
        }
        break; // Guerison
        case 2 :
        {
            sort_d_attaque(Victime,0.5);
        }
        break; // Sabotage
        case 3 :
        {
            sort_deplacement(Assaillant,2);
        }
        break; // Fugitif
        case 4 :
        {
            Victime->sort_actif_degatif=4;
            Victime->fin_sort_entrave=2;
        }
        break; // Empoisonnement
        case 5 :
        {
            Assaillant->sort_actif_positif=5;
            Assaillant->fin_sort_boost=1;
        }
        break; // Invincible
        case 6 :
        {
            sort_portee(Assaillant,2);
        }
        break; // Longue distance
        case 7 :
        {
            sort_d_attaque(Assaillant,2);
        }
        break; // Instinct de survie
        case 8 :
        {
            Assaillant->sort_actif_positif=8;
            Assaillant->fin_sort_boost=1;
        }
        break; // Furie
        case 9 :
        {
            Victime->sort_actif_degatif=9;
            Victime->fin_sort_entrave=1;
        }
        break; // Etourdissement
        case 10 :
        {
            Victime->sort_actif_degatif=10;
            Victime->fin_sort_entrave=1;
        }
        break; // Paralysie
        case 11 :
        {
            sort_de_vie(Assaillant,5,0,0);
            sort_de_vie(Victime,-5,0,0);
        }
        break; // Extraction
        case 12 :
        {
            sort_de_vie(Victime,-10,0,0);
        }
        break; // Brise glace
        case 13 :
        {
            sort_portee(Victime,0.5);
        }
        break; // Brouillard
        }
    }
}


void sortilege(BITMAP* echequier,int taille_carre,int terrain[30][44],t_personnage* Perso[4], int type,BITMAP* buffer,BITMAP* Mapp,int* f,int* confirm)
{
    blit(Mapp,buffer,0,0,0,0,1080,670);
    surbrillance_Sort(Perso[type],buffer,terrain,f);

    if ((mouse_b&1))
    {
        while(mouse_b&1);
        int colonne=mouse_x;
        int ligne=mouse_y; // on recupere la valeur de la souris ou on a cliquer
        while(mouse_b&1);

        int X=(Perso[type]->Pa)-(Perso[type]->Sort[(*(f))-4].puissance_sort);

        if(X >=0)
        {
            int trouve=-1;
            for (int i=0; i<4; i++)
            {
                if(((Perso[i]->affichage->position_pixel_ligne/taille_carre)==ligne/taille_carre)&&((Perso[i]->affichage->position_pixel_colonne/taille_carre)==colonne/taille_carre))
                {
                    printf("%d ",Perso[type]->Sort[(*(f))-4].puissance_sort);
                    trouve=i;
                    Perso[type]->Pa -= Perso[type]->Sort[(*(f))-4].puissance_sort;
                }
            }
            while(mouse_b&1);
            if (trouve!=-1)
            {
                Sort(Perso[trouve],Perso[type],Perso[type]->Sort[*(f)-4]);
                *(f)=0;
                *(confirm)=1;
            }
            else
            {
                allegro_message("Le sort n'a touche aucun personnage :( ");
                *(f)=0;
            }
        }
        else
        {

            allegro_message("Nombre de Pa insufissant ");
            *(f)=0;
        }

    }

    for (int i=0; i<4; i++)
    {
        if (Perso[i]->Pv<=0)
        {
            terrain[Perso[i]->affichage->position_pixel_ligne/taille_carre][Perso[i]->affichage->position_pixel_colonne/taille_carre]=Perso[i]->affichage->ancienne_couleur;
        }
    }

    for ( int i=0; i<30; i++)
    {
        for (int j=0; j<44; j++)
        {
            rectfill(echequier,  taille_carre*j,   taille_carre*i,  taille_carre*(j+1), taille_carre*(i+1),terrain[i][j]);
        }
    }

}


void sort_de_vie(t_personnage* Perso, int ajout_pv,float coefficient, int type)
{
    if (type==0)
    {
        Perso->Pv+=ajout_pv;
    }
    else if( type==1)
    {
        Perso->Pv*=coefficient;
    }
}

void sort_d_attaque(t_personnage* Perso,float coefficient)
{
    Perso->Pa*=coefficient;
}

void sort_deplacement(t_personnage* Perso,float coefficient)
{
    Perso->Pm*=coefficient;
}

void sort_portee(t_personnage* Perso,float coefficient)
{
    for (int i=0; i<4; i++)
    {
        Perso->Sort[i].portee_sort*=coefficient;
        Perso->Sort[i].portee_sort_moins*=coefficient;
    }
}

void Degats_Boost(t_personnage* Perso[4])
{
    for (int i=0; i<4; i++)
    {
        if ((Perso[i]->sort_actif_degatif!=0)&&((Perso[i]->compteur_sort_entrave<Perso[i]->fin_sort_entrave)))
        {
            switch( Perso[i]->sort_actif_degatif)
            {
            case 4 :
            {
                sort_de_vie(Perso[i],-2,0,0);
            }
            break;
            }
            Perso[i]->compteur_sort_entrave++;
        }
        else if ( (Perso[i]->sort_actif_degatif!=0)&&( Perso[i]->compteur_sort_entrave >= Perso[i]->fin_sort_entrave))
        {
            Perso[i]->sort_actif_degatif=0;
            Perso[i]->compteur_sort_entrave=0;
            Perso[i]->fin_sort_entrave=0;
        }
    }
    for (int i=0; i<4; i++)
    {
        if ((Perso[i]->sort_actif_positif!=0)&&((Perso[i]->compteur_sort_boost<Perso[i]->fin_sort_boost)))
        {
            Perso[i]->compteur_sort_boost++;
        }
        else if ( (Perso[i]->sort_actif_positif!=0)&&(Perso[i]->compteur_sort_boost >= Perso[i]->fin_sort_boost))
        {
            Perso[i]->sort_actif_positif=0;
            Perso[i]->compteur_sort_boost=0;
            Perso[i]->fin_sort_boost=0;
        }
    }

}
